# Hikvision utilities

https://github.com/apocaliss92/scrypted-hikvision-utilities - For requests and bugs

Utilities for hikvision:
- set OSD texts dynamically from scrypted